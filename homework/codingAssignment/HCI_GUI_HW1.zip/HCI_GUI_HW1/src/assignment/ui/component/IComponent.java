/**
 * This interface defines methods to draw a component on a UI window.
 */

package assignment.ui.component;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

import hci.mouseutils.MouseButtonState;

public interface IComponent {

    // UI Component interface methods

    /**
     * Paint component on UI window (using coordinates, dimensions and background color specified in component initialisation)
     * @param g - UI Graphics object
     */
    public void paintComponent(Graphics g);

    /**
     * Paint component on UI window with specified background color
     * @param g - UI Graphics object
     * @param backgroundColor - Background color
     */
    public void repaintComponent(Graphics g, Color backgroundColor);

    /**
     * Initialise component
     * @param x - x coordinate of component
     * @param y - y coordinate of component
     * @param width - Width of component
     * @param height - Height of component
     * @param label - Label text to be displayed
     * @param backgroundColor - Background color of component
     */
    public void init(int x, int y, int width, int height, String label, Color backgroundColor);

    /**
     * Get the background color of the component (same color used when it was created)
     * @return Background color
     */
    public Color getBackgroundColor();

    /**
     * Check if mouse position passed is over the component in the UI window
     * @param mousePosition
     * @return
     */
    public boolean isMouseOver(Point mousePosition);

    /**
     * Update mouse hover, left button click state over the component
     * @param mousePosition - Current position of the mouse
     * @param leftButtonState - State of the mouse left button
     * @param g - Graphics object
     */
    public void update(Point mousePosition, MouseButtonState leftButtonState, Graphics g);
}
