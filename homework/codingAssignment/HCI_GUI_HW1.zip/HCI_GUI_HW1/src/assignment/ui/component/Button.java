/**
 * This class implements the methods required to display a button
 * and detect events that have occurred over the button.
 */

package assignment.ui.component;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Stroke;

import hci.mouseutils.MouseButtonState;

public class Button extends Observable implements IComponent {

    // UI attributes
    private String label;
    private int x;
    private int y;
    private int width;
    private int height;
    private Color backgroundColor;

    // TODO: add any required member variables for keeping track of hover, mouse click state
    
    public Button(){
        super();
    }

    // Initialise coordinate, dimensions and background color of component
    @Override
    public void init(int x, int y, int width, int height, String label, Color backgroundColor) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.label = label;
        this.backgroundColor = backgroundColor;
    }

    @Override
    public Color getBackgroundColor(){
        return this.backgroundColor;
    }

    @Override
    public void paintComponent(Graphics g){
        this.paintComponent(g, this.backgroundColor);
    }

    @Override
    public void repaintComponent(Graphics g, Color backgroundColor){
        this.paintComponent(g, backgroundColor);
    }

    // Paint component on UI window
    private void paintComponent(Graphics g, Color backgroundColor){
        // draw rectangle
        g.setColor(Color.BLACK);
        Graphics2D g2 = (Graphics2D)g;
        Stroke s = g2.getStroke();
        g2.setStroke(new BasicStroke(2));
        g2.drawRect(this.x, this.y, this.width, this.height);
        g2.setStroke(s);

        // fill rectangle
        g.setColor(backgroundColor);
        g.fillRect(this.x, this.y, this.width, this.height);

        // draw label text
        g.setColor(Color.WHITE);
        g.setFont(new Font("TimesRoman", Font.PLAIN, 20));
        g.drawString(this.label, this.x+15, this.y+30);
    }

    // Check if mouse position is over the component
    @Override
    public boolean isMouseOver(Point mousePosition){
        // if mouse position is null, then mouse is outside the UI window
        if(mousePosition==null)
            return false;

        // else, check if the mouse position is within the component given it's position and dimensions
        // TODO: Add your implementation here. Change the below return statement to
        // return true if mouse is over the button, else return false.
        return false;
    }

    // Update hover state, left button click state
    // For hover state, if mouse is over the component, send a notification to all observers that a HoverOver event has occurred.
    // Else if mouse is not over the component's area, send a notification to all observers that a HoverOut event has occurred.
    // Similarly, if single/double click event is detected, notify that a SingleClick/DoubleClick event has occurred to all observers.
    public void update(Point mousePosition, MouseButtonState leftButtonState, Graphics g) {
        // TODO: Add your implementation of the update method here
    }

}
