/**
 * This interface defines methods to register observers and notify observers once an event has occurred.
 */

package assignment.ui.component;

import assignment.ui.event.EventType;
import assignment.ui.event.IEvent;
import assignment.ui.eventhandlers.IObserver;

public interface IObservable {
    /**
     * Notify event to registered observers
     * @param event - Event
     */
    public void notify(IEvent event);

    /**
     * Register observer to specified event type
     * @param observer - Observer
     * @param eventType - Event type
     */
    public void addListener(IObserver observer, EventType eventType);

    /**
     * Remove observer from registered list of observers for the specified event type
     * @param observer - Observer
     * @param eventType - Event type
     */
    public void removeListener(IObserver observer, EventType eventType);
}
