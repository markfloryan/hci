/**
 * This class implements the functions to register observers and notify observers once an event has occurred.
 */
package assignment.ui.component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import assignment.ui.event.EventType;
import assignment.ui.event.IEvent;
import assignment.ui.eventhandlers.IObserver;

public abstract class Observable implements IObservable {
	// Map from Event Type to List of Observers registered for each event type
    private Map<EventType, List<IObserver>> observersMap;
    
    public Observable() {
    		this.observersMap = new HashMap<EventType, List<IObserver>>();
    }
    
    // Register observer for specified event type
    @Override
    public void addListener(IObserver observer, EventType eventType){
        // TODO: Add your implementation here.
    }

    // Remove observer for specified event type
    @Override
    public void removeListener(IObserver observer, EventType eventType){
    		// TODO: Add your implementation here.
    }

    // Notify observers that have registered interest in the event
    @Override
    public void notify(IEvent event){
    		// TODO: Add your implementation here.
    }
}
