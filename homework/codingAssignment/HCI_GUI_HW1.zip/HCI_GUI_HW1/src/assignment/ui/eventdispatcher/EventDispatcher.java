/**
 * This class contains implementation for the UI events dispatcher thread.
 */

package assignment.ui.eventdispatcher;

import java.util.Timer;

public class EventDispatcher {
    // Member variable to store a reference to the UI window
    private GuiFrame guiFrame;

    public EventDispatcher(GuiFrame guiFrame){
        this.guiFrame = guiFrame;
    }

    // Method to start the events dispatcher thread
    public void start() throws Exception {
        // Start dispatcher thread for mouse events
        MouseEventDispatcher mouseEventDispatcher = new MouseEventDispatcher(this.guiFrame);
        Timer t = new Timer("mouseEventDispatcher", true);
        t.schedule(mouseEventDispatcher, 0, 10);
    }
}
