/**
 * This class contains implementation for the loop to poll mouse events
 */

package assignment.ui.eventdispatcher;

import java.awt.Point;
import java.util.List;
import java.util.TimerTask;

import assignment.ui.component.IComponent;
import hci.mouseutils.MouseButtonState;
import hci.mouseutils.MouseUtilities;

public class MouseEventDispatcher extends TimerTask {
    // Member variable to store a reference to the UI window
    private GuiFrame guiFrame;

    public MouseEventDispatcher(GuiFrame guiFrame) throws Exception{
        this.guiFrame = guiFrame;
        MouseUtilities.Initialize();
    }

    // This method is called every 10ms.
    // Get the current position of the mouse cursor, left button state
    // and call the update() method for each component in the GuiFrame
    @Override
    public void run() {
    		// Get current mouse position
        Point p = guiFrame.getMousePosition();
        MouseButtonState leftButtonState = MouseUtilities.getLeftButtonState();
        
        // Iterate through each component in the UI window
        List<IComponent> components = guiFrame.getAllComponents();
        for (IComponent c : components){
            c.update(p, leftButtonState, guiFrame.getGraphics());
        }
    }
}
