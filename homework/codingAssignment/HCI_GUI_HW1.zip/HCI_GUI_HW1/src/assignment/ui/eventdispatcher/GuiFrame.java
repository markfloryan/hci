/**
 * This class represents the UI window and is a container for all components added to the window.
 */

package assignment.ui.eventdispatcher;

import assignment.ui.component.IComponent;
import javax.swing.JFrame;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

public class GuiFrame extends JFrame {
    // Member variable to store list of components added to the window
    private ArrayList<IComponent> components;

    public GuiFrame(){
        components = new ArrayList<IComponent>();
    }

    public void addComponent(IComponent component){
        this.components.add(component);
    }

    // Paint all the components
    @Override
    public void paint(Graphics g){
        for(IComponent c : components){
            c.paintComponent(g);
        }
    }

    public List<IComponent> getAllComponents(){
        return this.components;
    }
}
