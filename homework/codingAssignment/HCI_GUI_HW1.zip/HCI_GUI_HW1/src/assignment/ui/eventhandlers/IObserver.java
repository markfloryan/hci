/**
 * This interface defines methods for the Observer
 */

package assignment.ui.eventhandlers;

import assignment.ui.event.IEvent;

public interface IObserver {
    /**
     * Handle event that was fired by a component
     * @param event - Event
     */
    public void handleEvent(IEvent event);
}
