/**
 * This Event Handler class contains implementation
 * for playing a beep sound whenever
 * an event of interest is dispatched.
 */

package assignment.ui.eventhandlers;

import assignment.ui.event.IEvent;
import java.awt.Toolkit;

public class PlayBeepHandler implements IObserver {
    @Override
    public void handleEvent(IEvent event){
        // Play beep sound
        Toolkit.getDefaultToolkit().beep();
    }
}
