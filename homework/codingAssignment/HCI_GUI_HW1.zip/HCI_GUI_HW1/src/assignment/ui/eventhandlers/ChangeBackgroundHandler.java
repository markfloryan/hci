/**
 * This Event Handler class contains implementation
 * to change the background of the component
 * whenever an event of interest is dispatched.
 */

package assignment.ui.eventhandlers;

import assignment.ui.component.IComponent;
import assignment.ui.event.IEvent;
import java.awt.Color;

public class ChangeBackgroundHandler implements IObserver {
    // TODO: Add any required member variables here

    public ChangeBackgroundHandler(Color backgroundColor){
        // TODO: Add initialisation code here
    }

    @Override
    public void handleEvent(IEvent event){
        // TODO: repaint source component's background 
        // with the color used to construct this event handler
    }
}
