/**
 * This Event Handler class contains implementation
 * to increment a counter whenever
 * an event of interest is dispatched.
 */

package assignment.ui.eventhandlers;

import assignment.ui.event.IEvent;

public class CountClicksHandler implements IObserver {
    // Member variable to store the count
    private int count;

    public CountClicksHandler(){
    	// Initialise count to 0
        this.count = 0;
    }

    @Override
    public void handleEvent(IEvent event) {
        // TODO: Increment and print count to console output
    }
}
