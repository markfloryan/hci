/**
 * This Event Handler class contains implementation
 * to display a popup message whenever
 * an event of interest is dispatched.
 */

package assignment.ui.eventhandlers;

import assignment.ui.event.IEvent;
import javax.swing.JOptionPane;

public class DisplayPopupHandler implements IObserver {
    @Override
    public void handleEvent(IEvent event){
        // display popup message
        JOptionPane.showMessageDialog(null, "Button Clicked", "Popup Message", JOptionPane.INFORMATION_MESSAGE);
    }
}
