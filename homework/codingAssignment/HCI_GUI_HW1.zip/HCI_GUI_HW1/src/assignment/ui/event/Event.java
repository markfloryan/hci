/**
 * This class contains implementation for the getters
 * and setters of an event object.
 */

package assignment.ui.event;

import assignment.ui.component.IComponent;
import java.awt.Graphics;
import java.awt.Point;

public class Event implements IEvent {
    private IComponent source;
    private Graphics g;
    private Point mousePosition;
    private EventType eventType;

    public Event(IComponent source, Graphics g, Point mousePosition){
        this.source = source;
        this.g = g;
        this.mousePosition = mousePosition;
    }

    @Override
    public IComponent getSource() {
         return this.source;
    }

    @Override
    public Graphics getGraphics() {
        return g;
    }

    @Override
    public Point getMousePosition() {
        return mousePosition;
    }

    @Override
    public EventType getEventType(){
        return this.eventType;
    }

    @Override
    public void setEventType(EventType eventType){
        this.eventType = eventType;
    }
}
