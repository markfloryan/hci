/**
 * This interface defines methods for Event objects
 */

package assignment.ui.event;

import assignment.ui.component.IComponent;
import java.awt.Graphics;
import java.awt.Point;

public interface IEvent {
    /**
     * Get source of event
     * @return IComponent object that fired the event
     */
    public IComponent getSource();

    /**
     * Get Graphics object for UI Window
     * @return UI Graphics
     */
    public Graphics getGraphics();

    /**
     * Get mouse position when event was fired
     * @return Mouse position
     */
    public Point getMousePosition();

    /**
     * Get Event Type
     * @return Event Type
     */
    public EventType getEventType();

    /**
     * Set Event Type
     * @param eventType - Event Type
     */
    public void setEventType(EventType eventType);
}
