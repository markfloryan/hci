/**
 * This class contains the implementation for the main() method to
 * 1. Create the UI window
 * 2. Create and display the button components
 * 3. Register observers (event handler) for specific events on each of the button components
 * 4. Start the events dispatcher
 *
 * The expected output is as follows:
 * 1. UI window containing 2 buttons
 * 2. Button 1 with original background color BLUE
 * 3. Button 2 with original background color GRAY
 * 4. Hovering mouse over button 1 should change the background color of the button to RED
 * 5. Hovering mouse out of button 1 should restore the background color to the original color of the button
 * 6. Hovering mouse over button 2 should change the background color of the button to GREEN
 * 7. Hovering mouse out of button 2 should restore the background color to the original color of the button
 * 8. Single click over button 1 should play a beep sound
 * 9. Single click over button 2 should play a beep sound and display a popup message
 * 10. Double click over button 2 should increment and print the value of a counter to console output
 */

import assignment.ui.component.Button;
import assignment.ui.component.IComponent;
import assignment.ui.component.IObservable;
import assignment.ui.event.EventType;
import assignment.ui.eventdispatcher.EventDispatcher;
import assignment.ui.eventdispatcher.GuiFrame;
import assignment.ui.eventhandlers.*;

import javax.swing.JFrame;
import java.awt.Color;

public class ButtonTester {
    public static void main(String[] args){

        /**
         * Create UI Window and draw 2 buttons at specified positions
         */

        // Create UI window
        GuiFrame frame = new GuiFrame();
        frame.setSize(600, 300);  // set window dimensions
        frame.setResizable(false);              // disable resizing window
        frame.setLocationRelativeTo(null);      // set initial location of window to screen centre

        // Create button 1 and add to UI window
        IComponent btn1 = new Button();
        btn1.init(10, 30, 100, 50, "Button 1", Color.BLUE);
        frame.addComponent(btn1);

        // Create button 2 and add to UI window
        IComponent btn2 = new Button();
        btn2.init(150, 30, 100, 50, "Button 2", Color.GRAY);
        frame.addComponent(btn2);

        // Display UI window
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        /**
         * Register button 1 Event Handlers
         */

        // Change color of Button 1 to RED when hovering mouse over button
        IObserver btn1Handler1 = new ChangeBackgroundHandler(Color.RED);
        IObservable oBtn1 = (IObservable)btn1;
        oBtn1.addListener(btn1Handler1, EventType.HoverOver);

        // Change color of Button 1 to original button color when hovering mouse out of button
        IObserver btn1Handler2 = new ChangeBackgroundHandler(btn1.getBackgroundColor());
        oBtn1.addListener(btn1Handler2, EventType.HoverOut);

        // Play beep sound on single click over button
        IObserver playBeepHandler = new PlayBeepHandler();
        oBtn1.addListener(playBeepHandler, EventType.SingleClick);

        /**
         * Register button 2 Event Handlers
         */

        // TODO: register the following handlers (observers) for button 2 events
        // 1. Change color of Button 2 to GREEN when hovering mouse over button
        // 2. Change color of Button 2 to original button color when hovering mouse out of button
        // 3. Play beep sound on single click over button
        // 4. Display popup message on single click over button
        // 5. Keep count of double click events over button
        
        /**
         * Start Events Dispatcher
         */
        try{
            EventDispatcher eventDispatcher = new EventDispatcher(frame);
            eventDispatcher.start();
        } catch (Exception ex){
            System.out.println(ex.getMessage());
            System.out.println(ex.getStackTrace());
        }

    }
}
